script.js

const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

// Game Variables
let block = { x: 50, y: 300, radius: 20, dy: 0, gravity: 0.5, jumpPower: -10, isJumping: false };  
let keys = {};
let score = 0;
let level = 1;
let coins = [];
let obstacles = [];
let platforms = [];
let finishPoint = { x: canvas.width - 50, y: 250, width: 50, height: 50 };
let gameOver = false;

// Level 1 Data
const level1Coins = [{ x: 200, y: 280 }, { x: 300, y: 280 }, { x: 400, y: 280 }];
const level1Obstacles = [{ x: 250, y: 350, width: 40, height: 40 }];
const level1Platforms = [
  { x: 10, y: 300, width: 100, height: 10 },
  { x: 200, y: 300, width: 100, height: 10 },
  { x: 600, y: 350, width: 100, height:10},
  { x: 800, y: 230, width: 100, height: 10 },
];

// Level 2 Data
const level2Coins = [{ x: 600, y: 280 }, { x: 700, y: 200 }];
const level2Obstacles = [{ x: 650, y: 300, width: 40, height: 40 }];
const level2Platforms = [
  { x: 550, y: 300, width: 100, height: 10 },
  { x: 900, y: 300, width: 100, height: 10 },
  { x: 1210, y: 300, width: 100, height: 10 },
];

// Level 3 Data
const level3Coins = [{ x: 900, y: 280 }, { x: 1000, y: 300 }];
const level3Obstacles = [{ x: 950, y: 300, width: 40, height: 40 }];
const level3Platforms = [
  { x: 850, y: 270, width: 100, height: 10 },
  { x: 1200, y: 250, width: 100, height: 10 },
  { x: 1500, y: 230, width: 100, height: 10 },
];

// Initialize Level 1
coins = level1Coins;
obstacles = level1Obstacles;
platforms = level1Platforms;

// Event Listeners
window.addEventListener('keydown', (e) => {
    if (gameOver && e.key === 'r') {
        resetGame();
    } else {
        keys[e.key] = true;
    }
});

window.addEventListener('keyup', (e) => {
    keys[e.key] = false;
});

// Game Loop
function gameLoop() {
    if (!gameOver) {
        update();
    }
    draw();
    requestAnimationFrame(gameLoop);
}

// Reset Game Function
function resetGame() {
    block.x = 50;
    block.y = 300;
    block.dy = 0;
    score = 0;
    level = 1;
    coins = level1Coins;
    obstacles = level1Obstacles;
    platforms = level1Platforms;
    finishPoint.x = canvas.width - 50;
    gameOver = false;
}

// Update Game State
function update() {
    if (keys['ArrowRight']) {
        block.x += 5;
    }
    if (keys['ArrowLeft']) {
        block.x -= 5;
    }
    if (keys[' ']) {
        if (!block.isJumping) {
            block.dy = block.jumpPower;
            block.isJumping = true;
        }
    }

    // Apply Gravity
    block.y += block.dy;
    block.dy += block.gravity;

    // Ground Collision
    if (block.y + block.radius * 2 >= canvas.height) {
        block.y = canvas.height - block.radius * 2;
        block.dy = 0;
        block.isJumping = false;
    }

    // Coin Collision
    coins = coins.filter(coin => {
        if (block.x < coin.x + 20 && block.x + block.radius * 2 > coin.x && block.y < coin.y + 20 && block.y + block.radius * 2 > coin.y) {
            score++;
            return false;
        }
        return true;
    });

    // Obstacle Collision (Triggers Game Over)
    obstacles.forEach(obstacle => {
        if (block.x < obstacle.x + obstacle.width && block.x + block.radius * 2 > obstacle.x && block.y + block.radius * 2 > obstacle.y) {
            gameOver = true;
        }
    });

    // Platform Collision
    platforms.forEach(platform => {
        if (block.x < platform.x + platform.width && block.x + block.radius * 2 > platform.x && block.y + block.radius * 2 >= platform.y && block.y + block.radius * 2 <= platform.y + platform.height) {
            block.y = platform.y - block.radius * 2;
            block.dy = 0;
            block.isJumping = false;
        }
    });

    // Check if the player has reached the finish line
    if (block.x > finishPoint.x) { 
        level++;
        block.x = 50;
        block.y = 300;
        block.dy = 0;

        if (level === 2) {
            coins = level2Coins;
            obstacles = level2Obstacles;
            platforms = level2Platforms;
            finishPoint.x = canvas.width - 50;
        } else if (level === 3) {
            coins = level3Coins;
            obstacles = level3Obstacles;
            platforms = level3Platforms;
            finishPoint.x = canvas.width - 50;
        } else {
            level = 1;
            coins = level1Coins;
            obstacles = level1Obstacles;
            platforms = level1Platforms;
            finishPoint.x = canvas.width - 50;
        }
    }
}

// Draw Game State
function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

     // Draw Mario-like Character
    ctx.beginPath();
    ctx.arc(block.x + block.radius, block.y + block.radius, block.radius, 0, Math.PI * 2);
    ctx.fillStyle = 'peachpuff';
    ctx.fill();
    ctx.strokeStyle = 'black';
    ctx.stroke();

    // Draw Hat
    ctx.fillStyle = 'red';
    ctx.fillRect(block.x + block.radius - 12, block.y + block.radius - 22, 24, 10);

    // Draw Eyes
    ctx.fillStyle = 'black';
    ctx.beginPath();
    ctx.arc(block.x + block.radius - 6, block.y + block.radius - 6, 4, 0, Math.PI * 2);
    ctx.arc(block.x + block.radius + 6, block.y + block.radius - 6, 4, 0, Math.PI * 2);
    ctx.fill();

    // Draw Mustache
    ctx.beginPath();
    ctx.arc(block.x + block.radius, block.y + block.radius + 5, 6, 0, Math.PI, false);
    ctx.stroke();
  
    // Draw Coins
    coins.forEach(coin => {
        ctx.beginPath();
        ctx.arc(coin.x, coin.y, 10, 0, Math.PI * 2);
        ctx.fillStyle = 'gold';
        ctx.fill();
    });

    // Draw Obstacles
    obstacles.forEach(obstacle => {
        ctx.fillStyle = 'red';
        ctx.fillRect(obstacle.x, obstacle.y, obstacle.width, obstacle.height);
    });

    // Draw Platforms
    platforms.forEach(platform => {
        ctx.fillStyle = 'brown';
        ctx.fillRect(platform.x, platform.y, platform.width, platform.height);
    });

    // Draw Finish Point
    ctx.fillStyle = 'green';
    ctx.fillRect(finishPoint.x, finishPoint.y, finishPoint.width, finishPoint.height);

    // Draw Game Over Message
    if (gameOver) {
        ctx.fillStyle = 'red';
        ctx.font = '30px Arial';
        ctx.fillText("Game Over! Press 'R' to Restart", canvas.width / 2 - 200, canvas.height / 2);
    }
}

// Start Game Loop
gameLoop();
